
Please read https://github.com/coreos/etcd-operator/blob/master/CONTRIBUTING.md#contribution-flow
