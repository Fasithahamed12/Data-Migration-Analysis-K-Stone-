#!/usr/bin/env bash

dep ensure -v
