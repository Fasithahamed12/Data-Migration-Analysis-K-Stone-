# 文档

[English](README.md)

你可以在本页面找到 kstone 相关文档

**注意**:  `master` 分支是开发中的 *非稳定* 版本。 对于稳定版本， 请看 [releases][releases].
## 安装部署
请参考 [安装文档](installation)

## 备份
请参考 [备份文档](backup)

## 提案
请参考 [提案](proposal)

[releases]: https://github.com/tkestack/kstone/releases