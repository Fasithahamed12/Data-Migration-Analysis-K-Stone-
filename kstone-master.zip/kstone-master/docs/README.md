# Documentation

[中文](README_CN.md)

In this page You can find kstone documentation.

**Note**: The `master` branch may be in an *unstable or even broken state* during development. For stable versions, see [releases][releases].
## Installation
please refer to [installation guide](installation)

## Backup
please refer to [backup guide](backup)

## Proposal
please refer to [proposal list](proposal)

[releases]: https://github.com/tkestack/kstone/releases