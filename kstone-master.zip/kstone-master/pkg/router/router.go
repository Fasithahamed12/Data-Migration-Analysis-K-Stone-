/*
 * Tencent is pleased to support the open source community by making TKEStack
 * available.
 *
 * Copyright (C) 2012-2023 Tencent. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use
 * this file except in compliance with the License. You may obtain a copy of the
 * License at
 *
 * https://opensource.org/licenses/Apache-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OF ANY KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations under the License.
 */

package router

import (
	"context"
	"crypto/tls"
	"fmt"
	"net/http"
	"net/http/httputil"
	"os"
	"time"

	"github.com/gin-contrib/pprof"
	"github.com/gin-gonic/gin"
	clientv3 "go.etcd.io/etcd/client/v3"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/client-go/tools/clientcmd"
	klog "k8s.io/klog/v2"

	"tkestack.io/kstone/cmd/kstone-api/config"
	"tkestack.io/kstone/pkg/authentication/request"
	"tkestack.io/kstone/pkg/backup"
	"tkestack.io/kstone/pkg/controllers/util"
	"tkestack.io/kstone/pkg/etcd"
	"tkestack.io/kstone/pkg/featureprovider"
	"tkestack.io/kstone/pkg/middlewares"

	_ "tkestack.io/kstone/pkg/authentication/providers" // import token and authenticator provider

	_ "tkestack.io/kstone/pkg/backup/providers" // import backup provider

	_ "tkestack.io/kstone/pkg/featureprovider/providers" // import feature provider

	clientset "tkestack.io/kstone/pkg/generated/clientset/versioned"
)

var (
	KubeScheme    = "https"
	KubeTarget    = os.Getenv("KUBE_TARGET")
	KubeToken     = os.Getenv("KUBE_TOKEN")
	WorkNamespace = "kstone"
)

const (
	GroupName   = "kstone.tkestack.io"
	VersionName = "v1alpha2"
	apiPrefix   = "/apis"
)

// SetWorkNamespace sets work namespace
func SetWorkNamespace(namespace string) {
	WorkNamespace = namespace
}

// NewRouter generates router
func NewRouter() *gin.Engine {
	r := gin.Default()

	if config.Cfg.EnableProfiling {
		pprof.Register(r, fmt.Sprintf("%s/debug/pprof", apiPrefix))
	}

	public := r.Group(apiPrefix)
	private := r.Group(apiPrefix)

	private.Use(middlewares.Auth())

	public.POST("/login", Login)

	private.GET("/:resource", ReverseProxy())
	private.POST("/:resource", ReverseProxy())
	private.GET("/:resource/:name", ReverseProxy())
	private.PUT("/:resource/:name", ReverseProxy())
	private.PATCH("/:resource/:name", ReverseProxy())
	private.DELETE("/:resource/:name", ReverseProxy())

	private.GET("/etcd/:etcdName", EtcdKeyList)
	private.GET("/backup/:etcdName", BackupList)
	private.GET("/features", FeatureList)

	private.GET("/users", UserList)
	private.PUT("/user", UserUpdate)
	private.POST("/user", UserAdd)
	private.DELETE("/user", UserDelete)

	return r
}

// ReverseProxy reverses proxy to kubernetes api
func ReverseProxy() gin.HandlerFunc {
	target := KubeTarget

	return func(c *gin.Context) {
		resource := c.Param("resource")
		name := c.Param("name")

		director := func(req *http.Request) {
			req.URL.Scheme = KubeScheme
			req.URL.Host = target
			req.Host = target
			// set Authorization to add k8s token
			req.Header = map[string][]string{
				"Authorization": {
					fmt.Sprintf("Bearer %s", KubeToken),
				},
			}

			var path string
			// handle different resource according to the resource type
			switch resource {
			case "etcdclusters":
				if name == "" {
					path = fmt.Sprintf("/apis/%s/%s/namespaces/%s/%s", GroupName, VersionName, WorkNamespace, resource)
				} else {
					path = fmt.Sprintf("/apis/%s/%s/namespaces/%s/%s/%s", GroupName, VersionName, WorkNamespace, resource, name)
				}
			case "secrets":
				if name == "" {
					if req.Method == http.MethodPost || req.Method == http.MethodGet {
						path = fmt.Sprintf("/api/v1/namespaces/%s/%s", WorkNamespace, resource)
					}
				} else {
					path = fmt.Sprintf("/api/v1/namespaces/%s/%s/%s", WorkNamespace, resource, name)
				}
			case "configmaps":
				if name == "" {
					if req.Method == http.MethodPost || req.Method == http.MethodGet {
						path = fmt.Sprintf("/api/v1/namespaces/%s/%s", WorkNamespace, resource)
					}
				} else {
					path = fmt.Sprintf("/api/v1/namespaces/%s/%s/%s", WorkNamespace, resource, name)
				}
			}

			req.URL.Path = path
			req.RequestURI = path
		}
		proxy := &httputil.ReverseProxy{Director: director}
		proxy.Transport = &http.Transport{
			Proxy:               http.ProxyFromEnvironment,
			TLSHandshakeTimeout: 10 * time.Second,
			TLSClientConfig:     &tls.Config{InsecureSkipVerify: true},
		}
		proxy.ServeHTTP(c.Writer, c.Request)
	}
}

// EtcdKeyList returns etcd key list
func EtcdKeyList(ctx *gin.Context) {
	etcdName := ctx.Param("etcdName")
	etcdKey := ctx.DefaultQuery("key", "")

	// generate etcd client
	cfg, err := clientcmd.BuildConfigFromFlags("", "")
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	clusterClient, err := clientset.NewForConfig(cfg)
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	cluster, err := clusterClient.KstoneV1alpha2().EtcdClusters(WorkNamespace).
		Get(context.TODO(), etcdName, metav1.GetOptions{})
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	annotations := cluster.Annotations
	secretName := ""
	if annotations != nil {
		if _, found := annotations["certName"]; found {
			secretName = annotations["certName"]
		}
	}
	clientConfigGetter := etcd.NewClientConfigSecretGetter(util.NewSimpleClientBuilder(""))
	klog.Infof("secretName: %s", secretName)
	path := fmt.Sprintf("%s/%s", cluster.Namespace, cluster.Name)
	config, err := clientConfigGetter.New(path, secretName)
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	config.Endpoints = []string{cluster.Status.ServiceName}

	klog.Infof("endpoint: %s, ca: %s, cert: %s, key: %s", cluster.Status.ServiceName, config.CaCert, config.Cert, config.Key)
	client, err := etcd.NewClientv3(config)
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}
	defer client.Close()

	if etcdKey == "" {
		resp, err := client.Get(context.TODO(), "", clientv3.WithPrefix(), clientv3.WithKeysOnly())
		if err != nil {
			klog.Errorf(err.Error())
			ctx.JSON(http.StatusInternalServerError, err)
			return
		}

		data := make([]string, 0)
		for _, value := range resp.Kvs {
			data = append(data, string(value.Key))
		}

		ctx.JSON(http.StatusOK, map[string]interface{}{
			"code": 0,
			"data": data,
		})
		return
	}
	klog.Infof("get value by key: %s", etcdKey)
	resp, err := client.Get(context.TODO(), etcdKey, clientv3.WithPrefix())
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}
	if resp.Count == 0 {
		ctx.JSON(http.StatusNotFound, map[string]interface{}{
			"code": 1,
			"data": "",
		})
	} else {
		result := map[string]interface{}{
			"code": 0,
			"err":  "",
		}
		if cluster.Annotations["kubernetes"] == "true" && etcdKey != "compact_rev_key" {
			jsonValue := etcd.ConvertToJSON(resp.Kvs[0])
			inMediaType, in, err := etcd.DetectAndExtract(resp.Kvs[0].Value)
			if err != nil {
				klog.Errorf(err.Error())
				ctx.JSON(http.StatusInternalServerError, err)
				return
			}
			respData, err := etcd.ConvertToData(inMediaType, in)
			if err != nil {
				klog.Errorf(err.Error())
				if respData == nil {
					respData = make(map[string]string)
				}
				result["err"] = err.Error()
			}
			respData["json"] = jsonValue
			respDataList := make([]map[string]string, 0)
			for dataType, value := range respData {
				respDataList = append(respDataList, map[string]string{
					"type": dataType,
					"data": value,
				})
			}
			result["data"] = respDataList
		} else {
			result["data"] = []map[string]string{
				{
					"type": "javascript",
					"data": string(resp.Kvs[0].Value),
				},
			}
		}
		ctx.JSON(http.StatusOK, result)
	}
}

// BackupList returns backup list
func BackupList(ctx *gin.Context) {
	etcdName := ctx.Param("etcdName")

	clientBuilder := util.NewSimpleClientBuilder("")

	// generate k8s client
	clusterClient, err := clientset.NewForConfig(clientBuilder.ConfigOrDie())
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	// get cluster
	cluster, err := clusterClient.KstoneV1alpha2().EtcdClusters(WorkNamespace).
		Get(context.TODO(), etcdName, metav1.GetOptions{})
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}

	// get backup config
	backupConfig, err := backup.GetBackupConfig(cluster)
	if err != nil {
		klog.Errorf("failed to get backup config,cluster %s,err is %v", cluster.Name, err)
		ctx.JSON(http.StatusInternalServerError, err)
	}

	// get specified backup storage provider
	storage, err := backup.GetBackupStorageProvider(string(backupConfig.StorageType), &backup.StorageConfig{
		KubeCli: clientBuilder.ClientOrDie(),
	})
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}
	resp, err := storage.List(cluster)
	if err != nil {
		klog.Errorf(err.Error())
		ctx.JSON(http.StatusInternalServerError, err)
		return
	}
	ctx.JSON(http.StatusOK, resp)
}

// FeatureList returns all features
func FeatureList(ctx *gin.Context) {
	features := featureprovider.ListFeatureProvider()
	ctx.JSON(http.StatusOK, features)
}

// UserList list all users
func UserList(ctx *gin.Context) {
	rsp, err := request.UserListRequest(ctx)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, *rsp)
		return
	}
	ctx.JSON(http.StatusOK, *rsp)
}

// UserUpdate updates users info
func UserUpdate(ctx *gin.Context) {
	rsp, err := request.UserUpdateRequest(ctx)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, *rsp)
		return
	}
	ctx.JSON(http.StatusOK, *rsp)
}

// UserAdd adds user
func UserAdd(ctx *gin.Context) {
	rsp, err := request.UserAddRequest(ctx)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, *rsp)
		return
	}
	ctx.JSON(http.StatusOK, *rsp)
}

// UserDelete deletes user
func UserDelete(ctx *gin.Context) {
	rsp, err := request.UserDeleteRequest(ctx)
	if err != nil {
		ctx.JSON(http.StatusInternalServerError, *rsp)
		return
	}
	ctx.JSON(http.StatusOK, *rsp)
}

// Login returns login info
func Login(ctx *gin.Context) {
	rsp, ok, err := request.LoginRequest(ctx)
	if !ok || err != nil {
		ctx.JSON(http.StatusUnauthorized, *rsp)
		return
	}
	ctx.JSON(http.StatusOK, *rsp)
}
